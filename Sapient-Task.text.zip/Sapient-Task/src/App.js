import React, { Component } from "react";
import BasicWizard from "./core/components/wizard/wizard";

class App extends Component {
  render() {
    return (
      <div className="App">
        <BasicWizard />
      </div>
    );
  }
}

export default App;
